-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Sam 29 Décembre 2018 à 13:34
-- Version du serveur :  10.1.23-MariaDB-9+deb9u1
-- Version de PHP :  7.0.30-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Agence`
--
CREATE DATABASE IF NOT EXISTS `Agence` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `Agence`;

-- --------------------------------------------------------

--
-- Structure de la table `Commune`
--

DROP TABLE IF EXISTS `Commune`;
CREATE TABLE IF NOT EXISTS `Commune` (
  `Num_Commune` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Commune` varchar(40) DEFAULT NULL,
  `NbHabitants_Commune` int(11) DEFAULT NULL,
  `CodePostal_Commune` int(5) NOT NULL,
  PRIMARY KEY (`Num_Commune`),
  UNIQUE KEY `Nom_Commune` (`Nom_Commune`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `Commune`
--

INSERT INTO `Commune` (`Num_Commune`, `Nom_Commune`, `NbHabitants_Commune`, `CodePostal_Commune`) VALUES
(1, 'QUIMPER', 63550, 29000),
(2, 'DOUARNENEZ', 14912, 29100),
(3, 'CONCARNEAU', 19048, 29900),
(4, 'BENODET', 3355, 29950),
(6, 'FOUESNANT', 9155, 29170),
(7, 'SAINT-JEAN-TROLIMON', 1003, 29120),
(10, 'PLOMELIN', 4097, 29700),
(13, 'ERGUE-GABERIC', 7855, 29500),
(25, 'PLEUVEN', 2630, 29170),
(26, 'BRIEC', 5376, 29510),
(29, 'POULDERGAT', 1246, 29100),
(30, 'CONFORT-MEILARS', 884, 29790),
(32, 'ROSPORDEN', 7227, 29140);

-- --------------------------------------------------------

--
-- Structure de la table `Locataire`
--

DROP TABLE IF EXISTS `Locataire`;
CREATE TABLE IF NOT EXISTS `Locataire` (
  `Num_Locataire` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Locataire` varchar(40) DEFAULT NULL,
  `Prenom_Locataire` varchar(40) DEFAULT NULL,
  `Naissance_Locataire` date DEFAULT NULL,
  `Telephone_Locataire` varchar(20) DEFAULT NULL,
  `Num_Logement` int(11) DEFAULT NULL,
  PRIMARY KEY (`Num_Locataire`),
  KEY `FK_Locataire_Num_Logement` (`Num_Logement`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `Locataire`
--

INSERT INTO `Locataire` (`Num_Locataire`, `Nom_Locataire`, `Prenom_Locataire`, `Naissance_Locataire`, `Telephone_Locataire`, `Num_Logement`) VALUES
(1, 'POULIQUEN', 'Christian', '1957-10-18', '0298902590', 1),
(2, 'BALANEC', 'Rosène', '1978-02-12', '0298925895', 2),
(11, 'BELBEOCH', 'Christophe', '1981-07-17', '0648026120', 6),
(12, 'DURAND', 'Marc', '1964-12-17', '0298918563', NULL),
(116, 'MAUREL', 'Tatiana', '1971-01-08', '0298942824', NULL),
(117, 'NAVARRO', 'Benjamin', '1947-03-15', '0298943262', NULL),
(118, 'CHARBONNIER', 'Carla', '1937-02-06', '0298984202', 15),
(119, 'MANGIN', 'Candice', '1997-02-10', '0298940204', NULL),
(120, 'VILLAIN', 'Kimberley', '1953-08-29', '0298962903', NULL),
(121, 'LAMBERT', 'Léonie', '1957-02-13', '0298940173', NULL),
(122, 'PREVOST', 'Valentine', '1979-05-09', '0298943492', NULL),
(123, 'PASQUIER', 'Lauriane', '1946-12-22', '0298950929', NULL),
(124, 'ROSSIGNOL', 'Renaud', '1932-03-08', '0298999212', NULL),
(125, 'ADAM', 'Léa', '1970-01-18', '0298986807', NULL),
(126, 'PETITJEAN', 'Candice', '1996-06-14', '0298937621', NULL),
(127, 'THIEBAUT', 'Yohan', '1951-12-19', '0298911011', NULL),
(128, 'MEUNIER', 'Laura', '1949-04-19', '0298978638', NULL),
(129, 'MARTY', 'Louis', '1978-07-18', '0298960450', NULL),
(130, 'MARTINEAU', 'Juliette', '1924-01-12', '0298912007', NULL),
(131, 'ROYER', 'Yüna', '1994-02-04', '0298913062', NULL),
(132, 'FOURNIER', 'Jérémy', '1975-10-27', '0298916544', NULL),
(133, 'SERRE', 'Lana', '1965-07-02', '0298937016', NULL),
(134, 'MARIN', 'Alexandra', '1945-03-15', '0298913471', NULL),
(135, 'HERVE', 'Ambre', '1962-11-22', '0298935003', NULL),
(136, 'DELAUNAY', 'Agathe', '1936-12-03', '0298964780', NULL),
(137, 'MAHE', 'Enzo', '1921-10-07', '0298918238', NULL),
(138, 'DELMAS', 'Adam', '1921-06-29', '0298990141', NULL),
(139, 'LEBRETON', 'Guillemette', '1967-12-23', '0298957260', NULL),
(140, 'DUVAL', 'Simon', '1964-09-09', '0298951997', NULL),
(141, 'THOMAS', 'Bienvenue', '1965-00-20', '0298999016', NULL),
(142, 'LE GOFF', 'Théo', '1952-08-15', '0298960747', NULL),
(143, 'COSTE', 'Bruno', '1943-01-15', '0298985268', NULL),
(144, 'GAY', 'Colin', '1936-09-17', '0298991055', NULL),
(145, 'BRAULT', 'Alexis', '1925-04-14', '0298979253', NULL),
(146, 'SIMON', 'Baptiste', '1939-02-03', '0298926641', 17),
(147, 'GOMEZ', 'Enzo', '1926-07-09', '0298903681', NULL),
(148, 'PAUL', 'Jules', '1997-10-22', '0298961502', NULL),
(149, 'GARCIA', 'Françoise', '1943-07-23', '0298973020', NULL),
(150, 'PARIS', 'Antonin', '1961-06-06', '0298911361', NULL),
(151, 'FAVRE', 'Élouan', '1990-09-10', '0298929050', NULL),
(152, 'HERNANDEZ', 'Julie', '1974-01-01', '0298975965', NULL),
(153, 'MARIE', 'Léo', '1924-01-25', '0298991284', NULL),
(154, 'FRANCOIS', 'Renaud', '1972-02-18', '0298944902', NULL),
(155, 'BARON', 'Maelys', '1932-04-21', '0298912375', 12),
(156, 'BARREAU', 'Guillemette', '1954-08-01', '0298913895', NULL),
(157, 'DAVID', 'Agathe', '1997-00-29', '0298984020', NULL),
(158, 'LEBRETON', 'Félix', '1945-12-25', '0298981457', NULL),
(159, 'ARNAUD', 'Mael', '1947-12-01', '0298936104', NULL),
(160, 'COCHET', 'Diego', '1954-00-08', '0298903491', NULL),
(161, 'COHEN', 'Maéva', '1920-00-04', '0298961888', NULL),
(162, 'THIERY', 'Valentine', '1971-04-14', '0298945279', NULL),
(163, 'DANIEL', 'Syrine', '1960-06-29', '0298903524', NULL),
(164, 'LEFEBVRE', 'Fanny', '1997-04-15', '0298942379', NULL),
(165, 'GUILLOT', 'Léa', '1974-06-26', '0298953066', NULL),
(166, 'LEON', 'Nolan', '1945-07-23', '0298932150', NULL),
(167, 'LAROCHE', 'Adrien', '1964-03-27', '0298927109', NULL),
(168, 'COCHET', 'Florentin', '1945-05-01', '0298936600', NULL),
(169, 'PELTIER', 'Adrien', '1995-02-23', '0298990221', NULL),
(170, 'GUILBERT', 'Mathis', '1973-05-26', '0298952567', NULL),
(171, 'MILLOT', 'Yüna', '1939-02-17', '0298933426', NULL),
(172, 'CROS', 'Gabriel', '1938-00-13', '0298938081', NULL),
(173, 'RAYNAUD', 'Corentin', '1944-05-04', '0298951169', NULL),
(174, 'GONÇALVES', 'Eva', '1946-09-14', '0298904325', NULL),
(175, 'BARTHELEMY', 'Maïlé', '1966-03-19', '0298956476', NULL),
(176, 'DA SILVA', 'Evan', '1979-01-04', '0298991900', NULL),
(177, 'DROUET', 'Kylian', '1937-02-25', '0298985429', NULL),
(178, 'JOURDAN', 'Noah', '1962-06-14', '0298993516', NULL),
(179, 'GUILBERT', 'Julien', '1979-05-10', '0298959811', NULL),
(180, 'DROUET', 'Timothée', '1981-06-10', '0298957714', NULL),
(181, 'MICHAUD', 'Katell', '1928-07-02', '0298953015', NULL),
(182, 'DESCHAMPS', 'Davy', '1968-12-11', '0298943640', NULL),
(183, 'BERGER', 'Corentin', '1946-10-16', '0298997879', NULL),
(184, 'LEVY', 'Thomas', '1940-04-14', '0298943321', NULL),
(185, 'CARLIER', 'Dylan', '1997-02-22', '0298932982', NULL),
(186, 'BONNIN', 'Maryam', '1937-06-29', '0298946475', NULL),
(187, 'BRAULT', 'Kyllian', '1998-01-28', '0298993049', NULL),
(188, 'MARCHAND', 'Kevin', '1932-01-01', '0298971254', NULL),
(189, 'POTTIER', 'Gabriel', '1975-03-27', '0298998793', NULL),
(190, 'FONTAINE', 'Charlotte', '1930-07-06', '0298902092', NULL),
(191, 'BARRE', 'Valentin', '1946-01-11', '0298935303', NULL),
(192, 'DAVID', 'Alexis', '1922-07-08', '0298910981', NULL),
(193, 'GUERIN', 'Renaud', '1960-01-02', '0298966419', NULL),
(194, 'PONS', 'Jordan', '1935-02-05', '0298934863', NULL),
(195, 'SANCHEZ', 'Malo', '1932-07-26', '0298955407', NULL),
(196, 'RAYMOND', 'Félix', '1981-10-09', '0298966827', NULL),
(197, 'LOISEAU', 'Rosalie', '1942-12-20', '0298904477', NULL),
(198, 'MILLET', 'Romane', '1983-07-14', '0298979139', NULL),
(199, 'DIAS', 'Mehdi', '1990-09-11', '0298974184', NULL),
(200, 'PREVOST', 'Lucas', '1943-11-08', '0298929315', 8),
(201, 'KLEIN', 'Lilou', '1955-06-20', '0298947592', NULL),
(202, 'LEMAIRE', 'Lucie', '1986-07-11', '0298952338', NULL),
(203, 'BAUDRY', 'Sara', '1934-07-03', '0298949688', NULL),
(204, 'FONTAINE', 'Margaux', '1974-07-16', '0298912442', NULL),
(205, 'DELAGE', 'Sara', '1942-09-11', '0298988701', NULL),
(206, 'RODRIGUEZ', 'Françoise', '1930-05-27', '0298931831', NULL),
(207, 'ROSSI', 'Capucine', '1933-02-01', '0298951844', NULL),
(208, 'BLIN', 'Jules', '1922-06-06', '0298920224', NULL),
(209, 'PERON', 'Juliette', '1957-05-10', '0298903798', NULL),
(210, 'MILLOT', 'Cédric', '1962-10-23', '0298922470', NULL),
(211, 'ROSSI', 'Noë', '1936-06-04', '0298948791', NULL),
(212, 'CLERC', 'Inès', '1987-07-12', '0298930361', NULL),
(213, 'NAVARRO', 'Clément', '1947-06-14', '0298996881', NULL),
(214, 'BENOIT', 'Dorian', '1951-01-03', '0298997033', NULL),
(215, 'GUICHARD', 'Lola', '1936-07-24', '0298974662', NULL),
(216, 'MERLE', 'Amine', '1920-04-15', '0298959445', NULL),
(217, 'LESAGE', 'Kimberley', '1958-05-24', '0298982645', NULL),
(218, 'GALLET', 'Lola', '1941-00-27', '0298937902', NULL),
(219, 'BENOIT', 'Anaïs', '1927-04-29', '0298991796', NULL),
(220, 'AUBERT', 'Amine', '1920-06-29', '0298905780', NULL),
(221, 'CORNU', 'Élise', '1953-05-12', '0298961437', NULL),
(222, 'FERRER', 'Julia', '1941-01-14', '0298987208', NULL),
(223, 'BRUN', 'Noémie', '1944-03-19', '0298929125', NULL),
(224, 'TORRES', 'Lutécia', '1946-08-08', '0298986935', NULL),
(225, 'HUMBERT', 'Lana', '1934-06-05', '0298922619', NULL),
(226, 'JACQUES', 'Sara', '1928-09-27', '0298916094', NULL),
(227, 'LEFEBVRE', 'Gaspard', '1985-08-04', '0298910145', NULL),
(228, 'FOURNIER', 'Timothée', '1985-01-08', '0298979294', NULL),
(229, 'DESCAMPS', 'Jade', '1996-09-17', '0298901796', NULL),
(230, 'BOULET', 'Jade', '1956-02-01', '0298969648', NULL),
(231, 'LAUNAY', 'Jade', '1927-11-06', '0298912859', NULL),
(232, 'MONNET', 'Cédric', '1950-06-14', '0298978701', NULL),
(233, 'CAMUS', 'Émile', '1952-10-02', '0298967726', NULL),
(234, 'CHAUVIN', 'Julien', '1961-06-13', '0298998881', NULL),
(235, 'BOURGEOIS', 'Inès', '1979-06-08', '0298906932', NULL),
(236, 'MULLER', 'Célia', '1923-08-23', '0298902461', NULL),
(237, 'BONHOMME', 'Katell', '1967-11-26', '0298947390', NULL),
(238, 'BOUQUET', 'Malo', '1981-05-16', '0298925016', NULL),
(239, 'MACE', 'Alexis', '1935-10-08', '0298900481', NULL),
(240, 'LECLERC', 'Maxence', '1927-05-13', '0298913534', NULL),
(241, 'FERNANDEZ', 'Luna', '1937-08-25', '0298979939', NULL),
(242, 'JOUBERT', 'Kylian', '1960-09-25', '0298908490', NULL),
(243, 'BERTIN', 'Clara', '1925-12-20', '0298922263', NULL),
(244, 'LAURENT', 'Léonie', '1941-09-20', '0298930172', NULL),
(245, 'DURANT', 'Elsa', '1953-08-12', '0298996288', NULL),
(246, 'ROSSI', 'Jérémy', '1998-11-16', '0298977079', NULL),
(247, 'DA SILVA', 'Baptiste', '1982-12-25', '0298930326', NULL),
(248, 'COLAS', 'Zoé', '1945-07-16', '0298981198', NULL),
(249, 'PINEAU', 'Capucine', '1952-12-14', '0298906720', NULL),
(250, 'MARIE', 'Noah', '1981-06-19', '0298960862', NULL),
(251, 'MARTINEAU', 'Margaux', '1972-07-23', '0298992269', NULL),
(252, 'BRUNEAU', 'Kilian', '1959-03-01', '0298953236', NULL),
(253, 'HENRY', 'Esteban', '1969-03-21', '0298922235', NULL),
(254, 'ROBERT', 'Thibault', '1967-06-21', '0298938979', NULL),
(255, 'COLAS', 'Lorenzo', '1964-09-05', '0298968824', NULL),
(256, 'REY', 'Adrien', '1989-12-21', '0298999714', NULL),
(257, 'MOULIN', 'Félix', '1981-12-14', '0298946691', NULL),
(258, 'THIBAULT', 'Louise', '1920-00-16', '0298900593', NULL),
(259, 'COMBE', 'Inès', '1990-09-13', '0298956211', NULL),
(260, 'LEGRAND', 'Charlotte', '1964-10-22', '0298994728', NULL),
(261, 'LAFON', 'Clara', '1973-08-14', '0298995114', NULL),
(262, 'MAILLARD', 'Louna', '1982-05-09', '0298914279', NULL),
(263, 'LEJEUNE', 'Mathilde', '1974-00-25', '0298944375', NULL),
(264, 'LABBE', 'Chaïma', '1966-04-02', '0298950317', NULL),
(265, 'FERRY', 'Mattéo', '1941-09-21', '0298913959', NULL),
(266, 'RUIZ', 'Mélanie', '1942-10-11', '0298915547', 8),
(267, 'PARENT', 'Timéo', '1921-04-07', '0298963230', NULL),
(268, 'PARENT', 'Maelys', '1939-10-05', '0298912310', NULL),
(269, 'KLEIN', 'Lou', '1984-05-17', '0298998626', 14),
(270, 'HENRY', 'Erwan', '1943-03-10', '0298971439', NULL),
(271, 'GUILLET', 'Noë', '1927-08-03', '0298947478', NULL),
(272, 'GAUTIER', 'Antonin', '1943-10-21', '0298912002', NULL),
(273, 'ROSSI', 'Mathis', '1964-00-21', '0298962396', NULL),
(274, 'GUILLEMIN', 'Émile', '1924-06-13', '0298962346', NULL),
(275, 'PICARD', 'Catherine', '1923-07-05', '0298907071', NULL),
(276, 'CHAUVEAU', 'Émile', '1946-04-09', '0298948814', NULL),
(277, 'MULLER', 'Solene', '1934-03-15', '0298935702', NULL),
(278, 'BARBIER', 'Rosalie', '1948-10-21', '0298900166', 10),
(279, 'FONTAINE', 'Lilou', '1966-00-20', '0298924468', NULL),
(280, 'DESCAMPS', 'Lucas', '1937-06-27', '0298938603', NULL),
(281, 'RAYNAUD', 'Lorenzo', '1946-05-04', '0298978775', NULL),
(282, 'PREVOT', 'Julien', '1995-10-24', '0298903060', NULL),
(283, 'LECOCQ', 'Nolan', '1985-08-25', '0298916480', NULL),
(284, 'BOUCHARD', 'Timéo', '1975-04-18', '0298967426', NULL),
(285, 'GUIBERT', 'Lily', '1966-10-01', '0298971749', NULL),
(286, 'CHARBONNIER', 'Tom', '1942-07-08', '0298974438', NULL),
(287, 'BODIN', 'Manon', '1932-01-26', '0298968495', NULL),
(288, 'WEBER', 'Valentine', '1958-09-08', '0298948758', NULL),
(289, 'JUNG', 'Carla', '1920-11-15', '0298917642', NULL),
(290, 'MAIRE', 'Alicia', '1947-05-09', '0298918307', NULL),
(291, 'LAROCHE', 'Nathan', '1994-07-22', '0298990733', NULL),
(292, 'JULIEN', 'Maelys', '1929-04-11', '0298966132', NULL),
(293, 'LAROCHE', 'Kyllian', '1941-02-25', '0298974458', NULL),
(294, 'MASSE', 'Mélanie', '1959-03-17', '0298977617', NULL),
(295, 'RAYNAUD', 'Marie', '1933-05-25', '0298964002', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `Logement`
--

DROP TABLE IF EXISTS `Logement`;
CREATE TABLE IF NOT EXISTS `Logement` (
  `Num_Logement` int(11) NOT NULL AUTO_INCREMENT,
  `Adresse_Logement` varchar(60) DEFAULT NULL,
  `Latitude_Logement` double DEFAULT NULL,
  `Longitude_Logement` double DEFAULT NULL,
  `Superficie_Logement` float DEFAULT NULL,
  `Loyer_Logement` float DEFAULT NULL,
  `Num_Quartier` int(11) DEFAULT NULL,
  `Num_Type` int(11) DEFAULT NULL,
  PRIMARY KEY (`Num_Logement`),
  KEY `FK_Logement_Num_Quartier` (`Num_Quartier`),
  KEY `FK_Logement_Num_Type` (`Num_Type`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `Logement`
--

INSERT INTO `Logement` (`Num_Logement`, `Adresse_Logement`, `Latitude_Logement`, `Longitude_Logement`, `Superficie_Logement`, `Loyer_Logement`, `Num_Quartier`, `Num_Type`) VALUES
(1, '5 rue Ti Coz', 47.986871, -4.068046, 65, 530, 1, 1),
(2, '18 rue Virginie Heriot', 48.000608, -4.097085, 45, 345, 2, 2),
(6, '118 rue Fernand Pelloutier', 47.9864224, -4.0722185, 85, 630, 1, 3),
(8, '116 rue Fernand Pelloutier', 47.9864233, -4.0721655, 87, 635, 1, 3),
(9, '14 rue Eugène Lucas', 48.0782865, -4.3305489, 68, 380, 4, 4),
(10, '15 rue des Camélias', 47.8767268, -4.098343, 96, 715, 8, 6),
(11, '1 rue Surcouf', 47.8793841, -4.1100786, 52, 405, 9, 4),
(12, '17 rue Docteur Paugam', 48.0912183, -4.3298015, 48, 397, 23, 4),
(13, '40 route du Prajou', 47.916927, -4.0345703, 115, 835, 12, 7),
(14, '30 Hent Kergoff', 47.9395293, -4.1545293, 120, 810, 30, 7),
(15, 'Kerguen', 47.8641349, -4.3102236, 21, 192, 14, 5),
(16, '12 rue Eugène Lucas', 48.0783649, -4.3306028, 78, 482, 4, 8),
(17, '11 lotissement de Ménez Tromillou', 48.056306, -4.4212998, 78, 600, 35, 3),
(23, '46 rue Jean Jaurès', 47.9936176, -4.0992583, 78, 589, 3, 1),
(24, '46 rue Jean Jaurès', 48.0911059, -4.3270303, 60, 482, 23, 4);

-- --------------------------------------------------------

--
-- Structure de la table `Quartier`
--

DROP TABLE IF EXISTS `Quartier`;
CREATE TABLE IF NOT EXISTS `Quartier` (
  `Num_Quartier` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Quartier` varchar(40) DEFAULT NULL,
  `Num_Commune` int(11) DEFAULT NULL,
  PRIMARY KEY (`Num_Quartier`),
  KEY `FK_Quartier_Num_Commune` (`Num_Commune`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `Quartier`
--

INSERT INTO `Quartier` (`Num_Quartier`, `Nom_Quartier`, `Num_Commune`) VALUES
(1, 'Ergue Armel', 1),
(2, 'Kerfeunteun', 1),
(3, 'Locmaria', 1),
(4, 'Pouldavid', 2),
(5, 'Ploaré', 2),
(6, 'Kerauret', 3),
(7, 'Lanriec', 3),
(8, 'Kersalé', 4),
(9, 'Penfoul', 4),
(11, 'Keryon', 6),
(12, 'Prajou', 25),
(13, 'Kerguilavant', 25),
(14, 'Kerguen', 7),
(15, 'Tronoan', 7),
(16, 'Kernevez', 1),
(17, 'Kernevez', 25),
(18, 'Le Braden', 1),
(19, 'Ty Bos', 1),
(20, 'Kervouyec', 1),
(22, 'Kermarron', 2),
(23, 'Centre Ville', 2),
(24, 'Terre Noire', 1),
(26, 'Poulduic', 13),
(27, 'Kerampensal', 13),
(28, 'Kerourvois', 13),
(29, 'La Croix Rouge', 13),
(30, 'Kergoff', 10),
(31, 'Picheri', 10),
(32, 'Prat Hir', 26),
(33, 'Gurvalé', 26),
(34, 'Kerharo', 2),
(35, 'Tromillou', 30),
(36, 'Trézulien', 2),
(37, 'Centre Ville', 1);

-- --------------------------------------------------------

--
-- Structure de la table `TypeLogement`
--

DROP TABLE IF EXISTS `TypeLogement`;
CREATE TABLE IF NOT EXISTS `TypeLogement` (
  `Num_Type` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Type` varchar(12) DEFAULT NULL,
  `Charges_Type` float DEFAULT NULL,
  PRIMARY KEY (`Num_Type`),
  UNIQUE KEY `Nom_Type` (`Nom_Type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `TypeLogement`
--

INSERT INTO `TypeLogement` (`Num_Type`, `Nom_Type`, `Charges_Type`) VALUES
(1, 'APP T3', 30),
(2, 'APP T1 bis', 18),
(3, 'MAI T4', 32),
(4, 'APP T2', 24),
(5, 'APP STUDIO', 12),
(6, 'MAI T5', 42),
(7, 'MAI T6', 55),
(8, 'APP T4', 38),
(10, 'MAI T3', 25),
(11, 'APP T1', 15);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Locataire`
--
ALTER TABLE `Locataire`
  ADD CONSTRAINT `FK_Locataire_Num_Logement` FOREIGN KEY (`Num_Logement`) REFERENCES `Logement` (`Num_Logement`);

--
-- Contraintes pour la table `Logement`
--
ALTER TABLE `Logement`
  ADD CONSTRAINT `FK_Logement_Num_Quartier` FOREIGN KEY (`Num_Quartier`) REFERENCES `Quartier` (`Num_Quartier`),
  ADD CONSTRAINT `FK_Logement_Num_Type` FOREIGN KEY (`Num_Type`) REFERENCES `TypeLogement` (`Num_Type`);

--
-- Contraintes pour la table `Quartier`
--
ALTER TABLE `Quartier`
  ADD CONSTRAINT `FK_Quartier_Num_Commune` FOREIGN KEY (`Num_Commune`) REFERENCES `Commune` (`Num_Commune`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
